//
//  ViewController.swift
//  assignment1
//
//  Created by zeking on 10/12/21.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet var erteulebi: [UIView]!
    @IBOutlet var ateulebi: [UIView]!
    @IBOutlet var aseulebi: [UIView]!
    let number = 123;
    
    override func viewDidLoad() {
        super.viewDidLoad()
        drawNumber()
    }
    
    func drawNumber(){
        var hundreds: Int!
        var tens: Int!
        var ones: Int!
        hundreds = number/100
        tens = number%10
        ones = (number/10)%10
        switchOnDisplay(hundreds: hundreds,tens: tens,ones: ones)
       
    }
    func switchOnDisplay(hundreds:Int!,tens:Int!,ones:Int!){
        colorNumb(arr: &aseulebi, n: hundreds)
        colorNumb(arr: &erteulebi, n: tens)
        colorNumb(arr: &ateulebi, n: ones)
    }
    func colorNumb(arr: inout [UIView], n:Int){
        switch n {
        case 0:
            switchOn(v:&arr[0])
            switchOn(v:&arr[1])
            switchOn(v:&arr[3])
            switchOn(v:&arr[4])
            switchOn(v:&arr[5])
            switchOn(v:&arr[6])
        case 1:
            switchOn(v:&arr[3])
            switchOn(v:&arr[5])
        case 2:
            switchOn(v:&arr[2])
            switchOn(v:&arr[1])
            switchOn(v:&arr[3])
            switchOn(v:&arr[4])
            switchOn(v:&arr[6])
        case 3:
            switchOn(v:&arr[2])
            switchOn(v:&arr[1])
            switchOn(v:&arr[3])
            switchOn(v:&arr[5])
            switchOn(v:&arr[6])
        case 4:
            switchOn(v:&arr[0])
            switchOn(v:&arr[2])
            switchOn(v:&arr[3])
            switchOn(v:&arr[5])
        case 5:
            switchOn(v:&arr[0])
            switchOn(v:&arr[1])
            switchOn(v:&arr[2])
            switchOn(v:&arr[5])
            switchOn(v:&arr[6])
        case 6:
            switchOn(v:&arr[0])
            switchOn(v:&arr[1])
            switchOn(v:&arr[2])
            switchOn(v:&arr[5])
            switchOn(v:&arr[6])
            switchOn(v:&arr[4])
        case 7:
            switchOn(v:&arr[0])
            switchOn(v:&arr[1])
            switchOn(v:&arr[3])
            switchOn(v:&arr[5])
        case 8:
            switchOn(v:&arr[0])
            switchOn(v:&arr[1])
            switchOn(v:&arr[2])
            switchOn(v:&arr[5])
            switchOn(v:&arr[6])
            switchOn(v:&arr[4])
            switchOn(v:&arr[3])
        case 9:
            switchOn(v:&arr[0])
            switchOn(v:&arr[1])
            switchOn(v:&arr[2])
            switchOn(v:&arr[5])
            switchOn(v:&arr[3])
        default:
            return
        }
    }
    func switchOn(v: inout UIView){
        v.backgroundColor = .red
    }
}

